package com.example.eva3_7_imagen_post;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    ImageView imagen;
    Bitmap bitmap = null;
    Handler handler = new Handler();

    Thread hilo = new Thread(){
        @Override
        public void run() {
            super.run();
            bitmap = cargarimagen("https://i.ytimg.com/vi/FDb0kIQXbfc/maxresdefault.jpg");
            handler.post(runimagen);
        }
    };

    Runnable runimagen=new Runnable() {
        @Override
        public void run() {
            imagen.setImageBitmap(bitmap);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imagen = findViewById(R.id.imageView);
        hilo.start();
    }

    private Bitmap cargarimagen (String url){
        Bitmap imagen = null;
        try {
            InputStream input = (InputStream) new URL(url).getContent();
            imagen = BitmapFactory.decodeStream(input);
        }catch (Exception e){
            e.printStackTrace();
        }
        return imagen;
    }
}
