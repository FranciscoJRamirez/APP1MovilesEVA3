package com.example.eva3_6_banner_post;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    ImageView img;
    SeekBar sb;
    int i = 0;
    Handler handler = new Handler();
    Runnable runn = new Runnable() {
        @Override
        public void run() {
            switch (i){
                case 0:
                    img.setImageResource(R.drawable.cloudy);
                    i++;
                    break;
                case 1:
                    img.setImageResource(R.drawable.rainy);
                    i++;
                    break;
                case 2:
                    img.setImageResource(R.drawable.sunny);
                    i++;
                    break;
                default:
                    img.setImageResource(R.drawable.thunderstorm);
                    i=0;

            }
        }
    };
    Thread hilo = new Thread(){
        @Override
        public void run() {
            super.run();
            while (true){
                try {
                    //sb.setMin(1000);

                    sb.setMax(10000);
                    int v = sb.getProgress();
                    if (v ==0) {
                        Thread.sleep(1000);
                    }else if(v==10000) {
                        Thread.sleep(50);
                    }else {
                        Thread.sleep(1000-(v/10));
                    }
                    handler.post(runn);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sb=findViewById(R.id.seekBar);
        img=findViewById(R.id.imageView);
        hilo.start();
    }
}
