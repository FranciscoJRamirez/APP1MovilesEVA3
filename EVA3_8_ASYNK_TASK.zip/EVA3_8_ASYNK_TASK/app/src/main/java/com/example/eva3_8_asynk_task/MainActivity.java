package com.example.eva3_8_asynk_task;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text=findViewById(R.id.txtlmao);
        Miclase micla = new Miclase();
        micla.execute(20, 500);
    }

    class Miclase extends AsyncTask<Integer, String, String>{
        //TODOS PUEDEN INTERACTUAR CON EL UI, EXCEPTO EL doInBackground

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            text.setText("INICIO DE LA CLASE ASINCRONA"+"\n");
        }
        //EQUIVALENTE AL RUN
        @Override
        protected String doInBackground(Integer... integers) {
            int iVeces = integers[0];
            int tiempo = integers[1];
            for (int i = 0; i<iVeces; i++){
                try {
                    Thread.sleep(tiempo);
                    publishProgress(String.valueOf(i));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return "FIN DE LA ASYNKTASK";


        }
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            text.append(values[0]+"\n");
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            text.append(s);
        }
    }
}
