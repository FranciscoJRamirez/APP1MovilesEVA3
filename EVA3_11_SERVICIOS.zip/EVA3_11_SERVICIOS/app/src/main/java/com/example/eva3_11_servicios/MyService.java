package com.example.eva3_11_servicios;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {
    Thread hilo = new Thread(){
        @Override
        public void run() {
            super.run();
            while (true){
                try {
                    Thread.sleep(500);
                    Log.wtf("myservice", "Tarea en segundo plano");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }
    };
    @Override
    public void onCreate() {
        super.onCreate();
        Log.wtf("MyService", "onCreate");
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        Log.wtf("MyService", "onStart");
        //AQUI HACEMOS EL TRABAJO DEL SERVICIO
        //CUALQUIER PROCESO EXTENSO DEBE USAR UN THREAD7
         hilo.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.wtf("MyService", "onDestroy");
        hilo.interrupt();

    }

    public MyService() {

    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
