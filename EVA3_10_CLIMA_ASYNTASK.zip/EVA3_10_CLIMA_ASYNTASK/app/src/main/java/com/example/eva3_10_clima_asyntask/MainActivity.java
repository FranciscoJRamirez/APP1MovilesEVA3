package com.example.eva3_10_clima_asyntask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    String [] nombre, grados, descripcion, temperatura;
    double [] tmp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new classAsynk().execute();
    }

    class classAsynk extends AsyncTask<Void, Void, String>{
        final String ruta = "https://samples.openweathermap.org/data/2.5/find?lat=55.5&lon=37.5&cnt=10&appid=b6907d289e10d714a6e88b30761fae22";

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s != null){
                //PROCESAMOS EL OBJETO O LOS OBJETOS JSON
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject jsonclima=new JSONObject(s);
                    JSONArray jsonCiudades= jsonclima.getJSONArray("list");
                    nombre = new String [jsonCiudades.length()];
                    grados = new String [jsonCiudades.length()];
                    descripcion = new String [jsonCiudades.length()];
                    tmp = new double [jsonCiudades.length()];
                    for (int i = 0; i<jsonCiudades.length();i++){
                        //leer cada ciudad y poner datos en una lista

                        JSONObject jsonciudad = jsonCiudades.getJSONObject(i);
                        //nombre de la ciudad
                        nombre[i]= jsonciudad.getString("name");
                        JSONObject jsontemp = new JSONObject(s), jsondesc = new JSONObject(s);
                        JSONArray jsontempa = jsonciudad.getJSONArray("main"), jsondes = jsonciudad.getJSONArray("weather");


                        JSONObject temperatura =jsontempa.getJSONObject(0), description = jsondes.getJSONObject(0);

                        tmp[i] = (temperatura.getDouble("temp")-32)*(5/9);
                        descripcion[i]= description.getString("description");
                        //Toast.makeText(getApplicationContext(), nombre[i], Toast.LENGTH_SHORT).show();





                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(), nombre[0]+ " "+tmp[0]+" "+descripcion[0], Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            //conexion
            String sResu= null;

            try {
                URL url = new URL(ruta);
                HttpURLConnection http = (HttpURLConnection)url.openConnection();
                http.connect();
                if (http.getResponseCode()==HttpURLConnection.HTTP_OK){
                    //leer respuesta
                    String line;
                    StringBuffer lineas = new StringBuffer();
                    InputStream inputStream = http.getInputStream();
                    InputStreamReader isReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(isReader);

                    while ((line = bufferedReader.readLine())!= null){
                        lineas.append(line);
                    }
                    sResu = lineas.toString();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return sResu;
        }
    }
}
