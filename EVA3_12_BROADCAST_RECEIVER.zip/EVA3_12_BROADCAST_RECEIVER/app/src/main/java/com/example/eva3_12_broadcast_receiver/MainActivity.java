package com.example.eva3_12_broadcast_receiver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    Intent inServicio;
    BroadcastReceiver br;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = findViewById(R.id.txt1);
        inServicio = new Intent(this, servicioxd.class);
        br = new MiBR();
        IntentFilter filtro = new IntentFilter("miservicio");
        registerReceiver(br, filtro);

    }

    public void stopServicio(View view) {
        stopService(inServicio);
    }

    public void startServicio(View view) {
        startService(inServicio);
    }

    class MiBR extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            txt.append(intent.getStringExtra("mensaje") + "\n");
        }
    }
}
