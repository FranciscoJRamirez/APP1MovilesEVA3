package com.example.eva3_9_asynk_banner;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    SeekBar seek;
    int progress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = findViewById(R.id.imageView);
        seek = findViewById(R.id.seekBar);
        seek.setMax(10000);
        micla miclas = new micla();
        miclas.execute();



    }

    class micla extends AsyncTask<Void, Integer, Void>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress = seek.getProgress();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progress=seek.getProgress();
            switch (values[0]){
                case 0:
                    img.setImageResource(R.drawable.cloudy);

                    break;
                case 1:
                    img.setImageResource(R.drawable.rainy);

                    break;
                case 2:
                    img.setImageResource(R.drawable.sunny);

                    break;
                default:
                    img.setImageResource(R.drawable.thunderstorm);


            }
        }

        @Override
        protected Void doInBackground(Void... integers) {

            for (int i=0;i<4;i++) {
                try {
                    if (progress == 0) {
                        Thread.sleep(1000);
                    } else if (progress == 10000) {
                        Thread.sleep(50);
                    } else {
                        Thread.sleep(1000 - (progress / 10));

                    }
                    publishProgress(i);
                    if (i==3){
                        i=0;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
            return null;

        }
    }
}
