package com.example.eva3_1_hilos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txthilo;
    Thread tMiHilo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txthilo = findViewById(R.id.txtHilo);
        tMiHilo = new Thread(){
            @Override
            public void run() {
                super.run();
                //aqui se hace el rollo
                int i = 0;
                while (true){
                    try {
                        Thread.sleep(1000);
                        Log.wtf("hilo", "i = "+i);
                        //txthilo.append("hilo---> i = "+i); NO FUNCIONA
                        i++;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Log.wtf("hilo interruptido", "interrumpido");
                        break;//se termina la ejecucion del hilo
                    }
                }
            }
        };
        tMiHilo.start();//siempre iniciar con start nunca con run

        Runnable rRun = new Runnable() {
            @Override
            public void run() {
                //aqui se hace el rollo
                int i = 0;
                while (true){
                    try {
                        Thread.sleep(1000);
                        Log.wtf("Runnable", "i = "+i);
                        //txthilo.append("Runnable---> i = "+i); NO FUNCIONA
                        i++;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        Thread rHilo = new Thread(rRun);
        rHilo.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        tMiHilo.interrupt();
    }
}
