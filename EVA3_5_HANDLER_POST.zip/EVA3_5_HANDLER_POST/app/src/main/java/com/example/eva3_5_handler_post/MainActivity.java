package com.example.eva3_5_handler_post;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtlmao;
    Thread hilo = new Thread(){
        @Override
        public void run() {
            super.run();
            //TRABAJO EN SEGUNDO PLANO
            while (true){
                try {
                    Thread.sleep(500);
                    handler.post(rMod);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
    };
    Runnable rMod= new Runnable() {
        @Override
        public void run() {
            //AQUI VA EL TRABAJO PARA MODIFICAR LA UI
            txtlmao.append("Hola mundo!! xd");
            txtlmao.append("\n");
        }
    };
    Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtlmao=findViewById(R.id.txtlmao);
        hilo.start();
    }
}
